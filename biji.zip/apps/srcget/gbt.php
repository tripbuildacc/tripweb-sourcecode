<?php
$output = "failed to get web code";

if ($_SERVER["REQUEST_METHOD"] === "POST" && !empty($_POST["url"])) {
    $url = trim($_POST["url"]);
    $api = "https://tripweb.page.gd/apis/sourcode/apiview?url=" . urlencode($url);

    $context = stream_context_create([
        "http" => [
            "timeout" => 15
        ]
    ]);

    $result = @file_get_contents($api, false, $context);

    if ($result !== false) {
        $output = htmlspecialchars($result);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Tripweb Tools</title>

<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">

<style>
body{
    margin:0;
    font-family:'Inter', sans-serif;
    background:#1e1e1e;
    color:#fff;
}
header{
    background:#2a2a2a;
    color:#ffcc00;
    text-align:center;
    padding:16px 0;
    font-weight:600;
    font-size:1.2rem;
}
.container{
    max-width:720px;
    margin:30px auto;
    padding:0 15px;
}
textarea{
    width:100%;
    min-height:80px;
    padding:10px;
    border-radius:6px;
    border:1px solid #444;
    background:#2a2a2a;
    color:#fff;
    margin-bottom:14px;
}
button{
    width:100%;
    padding:12px;
    border:none;
    border-radius:6px;
    background:#ffcc00;
    color:#111;
    font-size:1rem;
    font-weight:600;
    cursor:pointer;
    margin-bottom:14px;
}
.output{
    width:100%;
    min-height:200px;
    padding:10px;
    border-radius:6px;
    border:1px solid #444;
    background:#2a2a2a;
    overflow:auto;
    white-space:pre-wrap;
}
</style>
</head>

<body>

<header>Tripweb Apps</header>

<div class="container">
    <form method="post">
        <textarea name="url" placeholder="Enter URL here..." required><?= isset($_POST["url"]) ? htmlspecialchars($_POST["url"]) : "" ?></textarea>
        <button type="submit">View Web Code</button>
    </form>

    <div class="output"><?= $output ?></div>
</div>

</body>
</html>