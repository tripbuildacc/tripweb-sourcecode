<?php
header("Location: https://tripweb.page.gd/apps/dashboard");
exit;