<?php
/* label teks status */
$labels = [
    "new"    => "new",
    "soon"   => "coming soon",
    "fixed"  => "fixed",
    "beta"   => "Beta",
    "broken" => "being repaired"
];

/* ambil json */
$json = @file_get_contents('https://tripweb.page.gd/library/dashboard.json');
$data = $json ? json_decode($json, true) : ['apps'=>[]];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="0">
<title>Tripweb Apps</title>
<link rel="icon" type="image/png" href="https://tripweb.page.gd/library/weblogo.png"/>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
<style>
html{font-size:16px}
*{-webkit-text-size-adjust:100%;text-size-adjust:100%;box-sizing:border-box}
body{font-family:'Inter',sans-serif;background:#1e1e1e;color:#fff;margin:0;padding:0}
header{background:#2a2a2a;border-bottom:1px solid #3d3d3d;color:#ffcc00;text-align:center;font-weight:600;padding:18px 0;position:sticky;top:0;z-index:1000;font-size:1.3rem}
.container{max-width:720px;margin:30px auto;padding:0 15px;display:grid;gap:20px;grid-template-columns:1fr;}
.nav-container{background:#2a2a2a;border-bottom:1px solid #3d3d3d;padding:15px 0;position:sticky;top:60px;z-index:999}
.nav-menu{display:flex;justify-content:center;gap:12px;flex-wrap:wrap}
.nav-item{background:none;border:1px solid #3d3d3d;color:#fff;padding:10px 20px;border-radius:8px;font-size:.9rem;font-weight:600;cursor:pointer;transition:all .3s ease;text-decoration:none;position:relative;overflow:hidden}
.nav-item:hover{background:#ffcc00;color:#111;border-color:#ffcc00;transform:translateY(-2px)}
.nav-item:active{transform:scale(.95)}
.app{background:#2a2a2a;border:1px solid #3d3d3d;border-radius:12px;padding:16px;font-size:.9rem;position:relative;overflow:hidden}
.app.visible{opacity:1;transform:translateY(0)}
.app:hover{border-color:#ffcc00;transform:translateY(-4px);box-shadow:0 8px 25px rgba(255,204,0,0.1)}
.app:active{transform:translateY(-2px) scale(.98)}
.app-header{display:flex;justify-content:space-between;align-items:flex-start}
.app-title-wrap{display:flex;align-items:center;gap:8px;flex:1}
.app-title{font-size:1.1rem;font-weight:600;color:#fff}
.app-desc{font-size:.8rem;color:#bbb;margin:6px 0;line-height:1.4}
.app-badge{font-size:.65rem;font-weight:600;padding:2px 6px;border-radius:4px;border:none;background:transparent;color:#fff}
.app-badge.tripweb{background:#ffcc00;color:#111}
.arrow-btn{background:none;border:none;color:#ffcc00;font-size:1.5rem;cursor:pointer;transition:transform .3s ease}
.arrow-btn.open{transform:rotate(180deg)}
.arrow-btn:active{transform:scale(.9);transition:.1s}
.expand-area{max-height:0;overflow:hidden;transition:max-height .4s ease, padding .4s ease;padding:0 4px}
.expand-area.show{max-height:500px;padding:10px 4px 4px}
.sub-app{background:#222;border:1px solid #444;border-radius:8px;padding:10px 12px;margin-bottom:8px;display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap}
.sub-line{display:flex;align-items:center;gap:8px;flex:1 1 140px}
.sub-name{color:#fff;font-size:.85rem;font-weight:600}
.sub-type{color:#bbb;font-size:.75rem}
.badge{font-size:.65rem;font-weight:600;padding:2px 6px;border-radius:4px;border:none;background:transparent;color:#fff}
.badge.new{background:#42d100;color:#fff}
.badge.fixed{background:#92d100;color:#fff}
.badge.beta{background:#e6750b;color:#fff}
.badge.broken{background:#bf0000;color:#fff}
.badge.soon{background:#595959;color:#fff}
.use-btn{background:#ffcc00;color:#111;border:none;border-radius:6px;padding:6px 18px;font-size:.75rem;font-weight:600;cursor:pointer;transition:background .2s, transform .1s}
.use-btn:hover{background:#ffd93d}
.use-btn:active{transform:scale(.95)}
.click-hint{text-align:center;color:#666;font-size:.75rem;margin-top:20px;font-style:italic}
</style>
</head>  
<body>  
<header>Tripweb Apps</header>  
<div class="container">  
<?php foreach ($data['apps'] as $app): ?>
  <div class="app">  
    <div class="app-header">  
      <div class="app-title-wrap">  
        <div class="app-title"><?= htmlspecialchars($app['name']) ?></div>  
        <?php if (($app['mbt'] ?? true) !== false): ?>
          <span class="app-badge tripweb">Made by Tripweb</span>
        <?php endif; ?>
      </div>
      <button class="arrow-btn" onclick="toggleApp(this)">▼</button>  
    </div>  
    <div class="app-desc"><?= htmlspecialchars($app['description'] ?? '') ?></div>  
    <div class="expand-area">  
      <?php foreach (($app['subapps'] ?? []) as $sub): ?>
      <div class="sub-app">  
        <div class="sub-line">  
          <span class="sub-name"><?= htmlspecialchars($sub['name']) ?></span>  
          <span class="sub-type">| <?= htmlspecialchars($sub['type'] ?? '') ?></span>  
          <?php
            $st = strtolower(trim($sub['status'] ?? ''));
            if (isset($labels[$st])):
          ?>
            <span class="badge <?= $st ?>"><?= $labels[$st] ?></span>
          <?php endif; ?>
        </div>  
        <button class="use-btn" onclick="goUse('<?= htmlspecialchars($sub['path'] ?? '') ?>')">USE</button>  
      </div>  
      <?php endforeach; ?>
    </div>  
  </div>  
<?php endforeach; ?>
</div>  
<script>  
function toggleApp(btn){  
  const expand = btn.closest('.app').querySelector('.expand-area');  
  const isOpen = expand.classList.toggle('show');  
  btn.classList.toggle('open', isOpen);  
}  
function goUse(path){  
  location.href = "https://tripweb.page.gd/" + path;  
}  
</script>  
</body>  
</html>
