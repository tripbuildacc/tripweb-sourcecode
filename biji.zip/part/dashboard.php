<?php
// Ambil JSON dari URL
$json = @file_get_contents('https://tripweb.page.gd/library/dashboard.json');
$data = $json ? json_decode($json, true) : ['part' => []];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="0">
<title>Tripweb Part</title>
<link rel="icon" type="image/png" href="https://tripweb.page.gd/library/weblogo.png"/>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/animejs/3.2.1/anime.min.js"></script>
<style>
html{font-size:16px}
*{-webkit-text-size-adjust:100%;text-size-adjust:100%;box-sizing:border-box}
body{font-family:'Inter',sans-serif;background:#1e1e1e;color:#fff;margin:0;padding:0}
header{background:#2a2a2a;border-bottom:1px solid #3d3d3d;color:#ffcc00;text-align:center;font-weight:600;padding:18px 0;position:sticky;top:0;z-index:1000;font-size:1.3rem}
.nav-container{background:#2a2a2a;border-bottom:1px solid #3d3d3d;padding:15px 0;position:sticky;top:60px;z-index:999}
.nav-menu{display:flex;justify-content:center;gap:12px;flex-wrap:wrap}
.nav-item{background:none;border:1px solid #3d3d3d;color:#fff;padding:10px 20px;border-radius:8px;font-size:.9rem;font-weight:600;cursor:pointer;transition:all .3s ease;text-decoration:none;position:relative;overflow:hidden}
.nav-item:hover{background:#ffcc00;color:#111;border-color:#ffcc00;transform:translateY(-2px)}
.nav-item:active{transform:scale(.95)}
.container{max-width:720px;margin:40px auto;padding:0 15px;display:grid;gap:20px;grid-template-columns:1fr;}
.app{background:#2a2a2a;border:1px solid #3d3d3d;border-radius:12px;padding:20px;font-size:.9rem;position:relative;overflow:hidden;opacity:1;transform:translateY(0);transition:all .3s ease;cursor:pointer}
.app.visible{opacity:1;transform:translateY(0)}
.app:hover{border-color:#ffcc00;transform:translateY(-4px);box-shadow:0 8px 25px rgba(255,204,0,0.1)}
.app:active{transform:translateY(-2px) scale(.98)}
.app-title{font-size:1.2rem;font-weight:600;color:#fff;margin-bottom:8px}
.app-desc{font-size:.85rem;color:#bbb;line-height:1.4}
.app-badge{position:absolute;top:10px;right:10px;font-size:.65rem;font-weight:600;padding:3px 8px;border-radius:4px;background:#ffcc00;color:#111}
.footer{text-align:center;padding:20px;color:#666;font-size:.8rem;margin-top:40px}
.click-hint{text-align:center;color:#666;font-size:.75rem;margin-top:20px;font-style:italic}
</style>
</head>  

<body>  

<header>Tripweb Part</header>

<div class="container">
<?php foreach ($data['part'] as $item): ?>
  <div class="app" onclick="navigateTo('https://tripweb.page.gd/<?= htmlspecialchars($item['path']) ?>')">
    <div class="app-title"><?= htmlspecialchars($item['name']) ?></div>
    <div class="app-desc"><?= htmlspecialchars($item['description']) ?></div>
  </div>
<?php endforeach; ?>
</div>

<script>
function navigateTo(url) {
    const clickedElement = event.currentTarget;

    anime({
        targets: clickedElement,
        scale: [1, 0.95, 1],
        duration: 200,
        easing: 'easeInOutQuad'
    });

    setTimeout(() => {
        window.location.href = url;
    }, 300);
}

// Initialize animations on page load
document.addEventListener('DOMContentLoaded', function() {
const appCards = document.querySelectorAll('.app');
const navItems = document.querySelectorAll('.nav-item');

// Add hover effects for app cards
appCards.forEach(card => {
    card.addEventListener('mouseenter', function() {
        anime({
            targets: this,
            translateY: -4,
            duration: 200,
            easing: 'easeOutQuad'
        });
    });
    
    card.addEventListener('mouseleave', function() {
        anime({
            targets: this,
            translateY: 0,
            duration: 200,
            easing: 'easeOutQuad'
        });
    });
});

// Add hover effects for nav items
navItems.forEach(item => {
    item.addEventListener('mouseenter', function() {
        anime({
            targets: this,
            translateY: -2,
            duration: 150,
            easing: 'easeOutQuad'
        });
    });
    
    item.addEventListener('mouseleave', function() {
        anime({
            targets: this,
            translateY: 0,
            duration: 150,
            easing: 'easeOutQuad'
        });
    });
});

// Mark cards as visible
setTimeout(() => {
    appCards.forEach(card => {
        card.classList.add('visible');
    });
}, 100);
});
</script>

</body>
</html>
