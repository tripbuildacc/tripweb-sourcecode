<?php
if (isset($_GET['url']) && !empty($_GET['url'])) {
    $url = $_GET['url'];

    if (filter_var($url, FILTER_VALIDATE_URL)) {
        header("Location: " . $url);
        exit();
    } else {
        die("Invalid URL.");
    }
} else {
    die("Parameter 'url' not found.");
}
?>
