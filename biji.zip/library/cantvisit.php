<?php
$type = $_GET['type'] ?? '';

switch ($type) {

    case 'app-cs':

    header('Content-Type: text/html; charset=UTF-8');
    ?>
        <!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="0">
<title>Tripweb Apps</title>
<link rel="icon" type="image/png" href="https://tripweb.page.gd/library/weblogo.png"/>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body{
            margin: 0;
            height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            background: #1e1e1e;
            color: #fff;
            font-family: 'Inter', sans-serif;
            text-align: center;
        }
        h1{
            margin: 0;
            font-size: 3rem;
            color: #ffcc00;
        }
        p{
            margin: 8px 0 0;
            font-size: 1rem;
            color: #bbb;
        }
    </style>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
</head>
<body>
    <h1>COMING SOON</h1>
    <p>The time will come when this app will be released, just wait</p>
<p id="countdown" style="margin-top:15px; font-size:0.85rem; color:#999;">
    you will be redirected to the dashboard after 10 seconds
</p>

<div style="margin-top:15px;">
    <a href="https://tripweb.page.gd"
       style="
           padding:10px 22px;
           background:#ffcc00;
           color:#000;
           text-decoration:none;
           border-radius:6px;
           font-weight:600;
           display:inline-block;
       ">
        Dashboard
    </a>

    <a href="javascript:history.back()"
       style="
           padding:10px 22px;
           background:transparent;
           color:#bbb;
           text-decoration:none;
           border-radius:6px;
           font-weight:600;
           border:1px solid #444;
           display:inline-block;
           margin-left:10px;
       ">
        Back to last page
    </a>
</div>

<script>
    let seconds = 10;
    const countdownEl = document.getElementById('countdown');

    const timer = setInterval(() => {
        seconds--;
        countdownEl.textContent =
            `you will be redirected to the dashboard after ${seconds} seconds`;

        if (seconds <= 0) {
            clearInterval(timer);
            window.location.href = 'https://tripweb.page.gd';
        }
    }, 1000);
</script>

</body>
</html>
         
<?php
    break;

case 'app-br':

    header('Content-Type: text/html; charset=UTF-8');
    ?>
        <!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="0">
<title>Tripweb Apps</title>
<link rel="icon" type="image/png" href="https://tripweb.page.gd/library/weblogo.png"/>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body{
            margin: 0;
            height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            background: #1e1e1e;
            color: #fff;
            font-family: 'Inter', sans-serif;
            text-align: center;
        }
        h1{
            margin: 0;
            font-size: 3rem;
            color: #ffcc00;
        }
        p{
            margin: 8px 0 0;
            font-size: 1rem;
            color: #bbb;
        }
    </style>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
</head>
<body>
    <h1>BEING REPAIRED</h1>
    <p>This sub-app encountered an error that broke its main functionality, so it is temporarily closed and is being fixed.</p>
<p id="countdown" style="margin-top:15px; font-size:0.85rem; color:#999;">
    you will be redirected to the dashboard after 10 seconds
</p>

<div style="margin-top:15px;">
    <a href="https://tripweb.page.gd"
       style="
           padding:10px 22px;
           background:#ffcc00;
           color:#000;
           text-decoration:none;
           border-radius:6px;
           font-weight:600;
           display:inline-block;
       ">
        Dashboard
    </a>

    <a href="javascript:history.back()"
       style="
           padding:10px 22px;
           background:transparent;
           color:#bbb;
           text-decoration:none;
           border-radius:6px;
           font-weight:600;
           border:1px solid #444;
           display:inline-block;
           margin-left:10px;
       ">
        Back to last page
    </a>
</div>

<script>
    let seconds = 10;
    const countdownEl = document.getElementById('countdown');

    const timer = setInterval(() => {
        seconds--;
        countdownEl.textContent =
            `you will be redirected to the dashboard after ${seconds} seconds`;

        if (seconds <= 0) {
            clearInterval(timer);
            window.location.href = 'https://tripweb.page.gd';
        }
    }, 1000);
</script>

</body>
</html>
         
<?php
    break;

case 'api-cs':

    header('Content-Type: text/html; charset=UTF-8');
    ?>
        <!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="0">
<title>Tripweb Apis</title>
<link rel="icon" type="image/png" href="https://tripweb.page.gd/library/weblogo.png"/>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body{
            margin: 0;
            height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            background: #1e1e1e;
            color: #fff;
            font-family: 'Inter', sans-serif;
            text-align: center;
        }
        h1{
            margin: 0;
            font-size: 3rem;
            color: #ffcc00;
        }
        p{
            margin: 8px 0 0;
            font-size: 1rem;
            color: #bbb;
        }
    </style>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
</head>
<body>
    <h1>COMING SOON</h1>
    <p>The time will come when this api will be released, just wait</p>
<p id="countdown" style="margin-top:15px; font-size:0.85rem; color:#999;">
    you will be redirected to the dashboard after 10 seconds
</p>

<div style="margin-top:15px;">
    <a href="https://tripweb.page.gd"
       style="
           padding:10px 22px;
           background:#ffcc00;
           color:#000;
           text-decoration:none;
           border-radius:6px;
           font-weight:600;
           display:inline-block;
       ">
        Dashboard
    </a>

    <a href="javascript:history.back()"
       style="
           padding:10px 22px;
           background:transparent;
           color:#bbb;
           text-decoration:none;
           border-radius:6px;
           font-weight:600;
           border:1px solid #444;
           display:inline-block;
           margin-left:10px;
       ">
        Back to last page
    </a>
</div>

<script>
    let seconds = 10;
    const countdownEl = document.getElementById('countdown');

    const timer = setInterval(() => {
        seconds--;
        countdownEl.textContent =
            `you will be redirected to the dashboard after ${seconds} seconds`;

        if (seconds <= 0) {
            clearInterval(timer);
            window.location.href = 'https://tripweb.page.gd';
        }
    }, 1000);
</script>

</body>
</html>
         
<?php
    break;

case 'api-br':

    header('Content-Type: text/html; charset=UTF-8');
    ?>
        <!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="0">
<title>Tripweb Apis</title>
<link rel="icon" type="image/png" href="https://tripweb.page.gd/library/weblogo.png"/>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body{
            margin: 0;
            height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            background: #1e1e1e;
            color: #fff;
            font-family: 'Inter', sans-serif;
            text-align: center;
        }
        h1{
            margin: 0;
            font-size: 3rem;
            color: #ffcc00;
        }
        p{
            margin: 8px 0 0;
            font-size: 1rem;
            color: #bbb;
        }
    </style>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
</head>
<body>
    <h1>BEING REPAIRED</h1>
    <p>This sub-api encountered an error that broke its main functionality, so it is temporarily closed and is being fixed.</p>
<p id="countdown" style="margin-top:15px; font-size:0.85rem; color:#999;">
    you will be redirected to the dashboard after 10 seconds
</p>

<div style="margin-top:15px;">
    <a href="https://tripweb.page.gd"
       style="
           padding:10px 22px;
           background:#ffcc00;
           color:#000;
           text-decoration:none;
           border-radius:6px;
           font-weight:600;
           display:inline-block;
       ">
        Dashboard
    </a>

    <a href="javascript:history.back()"
       style="
           padding:10px 22px;
           background:transparent;
           color:#bbb;
           text-decoration:none;
           border-radius:6px;
           font-weight:600;
           border:1px solid #444;
           display:inline-block;
           margin-left:10px;
       ">
        Back to last page
    </a>
</div>

<script>
    let seconds = 10;
    const countdownEl = document.getElementById('countdown');

    const timer = setInterval(() => {
        seconds--;
        countdownEl.textContent =
            `you will be redirected to the dashboard after ${seconds} seconds`;

        if (seconds <= 0) {
            clearInterval(timer);
            window.location.href = 'https://tripweb.page.gd';
        }
    }, 1000);
</script>

</body>
</html>
         
<?php
    break;

case 'nou403':

    header('Content-Type: text/html; charset=UTF-8');
    ?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="0">
<title>Tripweb Main</title>
<link rel="icon" type="image/png" href="https://tripweb.page.gd/library/weblogo.png"/>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body{
            margin: 0;
            height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            background: #1e1e1e;
            color: #fff;
            font-family: 'Inter', sans-serif;
            text-align: center;
        }
        h1{
            margin: 0;
            font-size: 3rem;
            color: #ffcc00;
        }
        p{
            margin: 8px 0 0;
            font-size: 1rem;
            color: #bbb;
        }
    </style>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
</head>
<body>
    <h1>FORBIDDEN</h1>
    <p>tripweb prohibits you from accessing this section.</p>
<p id="countdown" style="margin-top:15px; font-size:0.85rem; color:#999;">
    you will be redirected to the dashboard after 10 seconds
</p>

<div style="margin-top:15px;">
    <a href="https://tripweb.page.gd"
       style="
           padding:10px 22px;
           background:#ffcc00;
           color:#000;
           text-decoration:none;
           border-radius:6px;
           font-weight:600;
           display:inline-block;
       ">
        Dashboard
    </a>

    <a href="javascript:history.back()"
       style="
           padding:10px 22px;
           background:transparent;
           color:#bbb;
           text-decoration:none;
           border-radius:6px;
           font-weight:600;
           border:1px solid #444;
           display:inline-block;
           margin-left:10px;
       ">
        Back to last page
    </a>
</div>

<script>
    let seconds = 10;
    const countdownEl = document.getElementById('countdown');

    const timer = setInterval(() => {
        seconds--;
        countdownEl.textContent =
            `you will be redirected to the dashboard after ${seconds} seconds`;

        if (seconds <= 0) {
            clearInterval(timer);
            window.location.href = 'https://tripweb.page.gd';
        }
    }, 1000);
</script>

</body>
</html>
 
<?php
    break;

case 'nou404':

    header('Content-Type: text/html; charset=UTF-8');
    ?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="0">
<title>Tripweb Main</title>
<link rel="icon" type="image/png" href="https://tripweb.page.gd/library/weblogo.png"/>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body{
            margin: 0;
            height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            background: #1e1e1e;
            color: #fff;
            font-family: 'Inter', sans-serif;
            text-align: center;
        }
        h1{
            margin: 0;
            font-size: 3rem;
            color: #ffcc00;
        }
        p{
            margin: 8px 0 0;
            font-size: 1rem;
            color: #bbb;
        }
    </style>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
</head>
<body>
    <h1>NOT FOUND</h1>
    <p>It looks like the file has been deleted, never existed, or had its address changed.</p>
<p id="countdown" style="margin-top:15px; font-size:0.85rem; color:#999;">
    you will be redirected to the dashboard after 10 seconds
</p>

<div style="margin-top:15px;">
    <a href="https://tripweb.page.gd"
       style="
           padding:10px 22px;
           background:#ffcc00;
           color:#000;
           text-decoration:none;
           border-radius:6px;
           font-weight:600;
           display:inline-block;
       ">
        Dashboard
    </a>

    <a href="javascript:history.back()"
       style="
           padding:10px 22px;
           background:transparent;
           color:#bbb;
           text-decoration:none;
           border-radius:6px;
           font-weight:600;
           border:1px solid #444;
           display:inline-block;
           margin-left:10px;
       ">
        Back to last page
    </a>
</div>

<script>
    let seconds = 10;
    const countdownEl = document.getElementById('countdown');

    const timer = setInterval(() => {
        seconds--;
        countdownEl.textContent =
            `you will be redirected to the dashboard after ${seconds} seconds`;

        if (seconds <= 0) {
            clearInterval(timer);
            window.location.href = 'https://tripweb.page.gd';
        }
    }, 1000);
</script>

</body>
</html>
 
<?php
    break;

case 'nou500':

    header('Content-Type: text/html; charset=UTF-8');
    ?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="0">
<title>Tripweb Main</title>
<link rel="icon" type="image/png" href="https://tripweb.page.gd/library/weblogo.png"/>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body{
            margin: 0;
            height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            background: #1e1e1e;
            color: #fff;
            font-family: 'Inter', sans-serif;
            text-align: center;
        }
        h1{
            margin: 0;
            font-size: 3rem;
            color: #ffcc00;
        }
        p{
            margin: 8px 0 0;
            font-size: 1rem;
            color: #bbb;
        }
    </style>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
</head>
<body>
    <h1>INTERNAL SERVER ERROR</h1>
    <p>It looks like tripweb has an error that is preventing this section from loading.</p>
<p id="countdown" style="margin-top:15px; font-size:0.85rem; color:#999;">
    you will be redirected to the dashboard after 10 seconds
</p>

<div style="margin-top:15px;">
    <a href="https://tripweb.page.gd"
       style="
           padding:10px 22px;
           background:#ffcc00;
           color:#000;
           text-decoration:none;
           border-radius:6px;
           font-weight:600;
           display:inline-block;
       ">
        Dashboard
    </a>

    <a href="javascript:history.back()"
       style="
           padding:10px 22px;
           background:transparent;
           color:#bbb;
           text-decoration:none;
           border-radius:6px;
           font-weight:600;
           border:1px solid #444;
           display:inline-block;
           margin-left:10px;
       ">
        Back to last page
    </a>
</div>

<script>
    let seconds = 10;
    const countdownEl = document.getElementById('countdown');

    const timer = setInterval(() => {
        seconds--;
        countdownEl.textContent =
            `you will be redirected to the dashboard after ${seconds} seconds`;

        if (seconds <= 0) {
            clearInterval(timer);
            window.location.href = 'https://tripweb.page.gd';
        }
    }, 1000);
</script>

</body>
</html>
 
<?php
    break;

case 'nou502':

    header('Content-Type: text/html; charset=UTF-8');
    ?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="0">
<title>Tripweb Main</title>
<link rel="icon" type="image/png" href="https://tripweb.page.gd/library/weblogo.png"/>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body{
            margin: 0;
            height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            background: #1e1e1e;
            color: #fff;
            font-family: 'Inter', sans-serif;
            text-align: center;
        }
        h1{
            margin: 0;
            font-size: 3rem;
            color: #ffcc00;
        }
        p{
            margin: 8px 0 0;
            font-size: 1rem;
            color: #bbb;
        }
    </style>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
</head>
<body>
    <h1>BAD GATEWAY</h1>
    <p>there is a problem with tripweb connectivity or your connectivity</p>
<p id="countdown" style="margin-top:15px; font-size:0.85rem; color:#999;">
    you will be redirected to the dashboard after 10 seconds
</p>

<div style="margin-top:15px;">
    <a href="https://tripweb.page.gd"
       style="
           padding:10px 22px;
           background:#ffcc00;
           color:#000;
           text-decoration:none;
           border-radius:6px;
           font-weight:600;
           display:inline-block;
       ">
        Dashboard
    </a>

    <a href="javascript:history.back()"
       style="
           padding:10px 22px;
           background:transparent;
           color:#bbb;
           text-decoration:none;
           border-radius:6px;
           font-weight:600;
           border:1px solid #444;
           display:inline-block;
           margin-left:10px;
       ">
        Back to last page
    </a>
</div>

<script>
    let seconds = 10;
    const countdownEl = document.getElementById('countdown');

    const timer = setInterval(() => {
        seconds--;
        countdownEl.textContent =
            `you will be redirected to the dashboard after ${seconds} seconds`;

        if (seconds <= 0) {
            clearInterval(timer);
            window.location.href = 'https://tripweb.page.gd';
        }
    }, 1000);
</script>

</body>
</html>
 
<?php
    break;

case 'nou503':

    header('Content-Type: text/html; charset=UTF-8');
    ?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="0">
<title>Tripweb Main</title>
<link rel="icon" type="image/png" href="https://tripweb.page.gd/library/weblogo.png"/>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body{
            margin: 0;
            height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            background: #1e1e1e;
            color: #fff;
            font-family: 'Inter', sans-serif;
            text-align: center;
        }
        h1{
            margin: 0;
            font-size: 3rem;
            color: #ffcc00;
        }
        p{
            margin: 8px 0 0;
            font-size: 1rem;
            color: #bbb;
        }
    </style>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
</head>
<body>
    <h1>SERVICE UNAVAILABLE</h1>
    <p>tripweb server is temporarily unresponsive to your request</p>
<p id="countdown" style="margin-top:15px; font-size:0.85rem; color:#999;">
    you will be redirected to the dashboard after 10 seconds
</p>

<div style="margin-top:15px;">
    <a href="https://tripweb.page.gd"
       style="
           padding:10px 22px;
           background:#ffcc00;
           color:#000;
           text-decoration:none;
           border-radius:6px;
           font-weight:600;
           display:inline-block;
       ">
        Dashboard
    </a>

    <a href="javascript:history.back()"
       style="
           padding:10px 22px;
           background:transparent;
           color:#bbb;
           text-decoration:none;
           border-radius:6px;
           font-weight:600;
           border:1px solid #444;
           display:inline-block;
           margin-left:10px;
       ">
        Back to last page
    </a>
</div>

<script>
    let seconds = 10;
    const countdownEl = document.getElementById('countdown');

    const timer = setInterval(() => {
        seconds--;
        countdownEl.textContent =
            `you will be redirected to the dashboard after ${seconds} seconds`;

        if (seconds <= 0) {
            clearInterval(timer);
            window.location.href = 'https://tripweb.page.gd';
        }
    }, 1000);
</script>

</body>
</html>
 
<?php
    break;
   
 default:
    http_response_code(400);
    echo 'ignorant and stupid codebreaker';
    break;
}