<?php
$file = 'dashboard.visited.json';

// kalau file belum ada, buat default
if (!file_exists($file)) {
    $data = [
        "today" => 0,
        "today_willreset" => date("Y-m-d 00:00:00", strtotime("+1 day")),
        "week" => 0,
        "week_willreset" => date("Y-m-d 00:00:00", strtotime("next monday")),
        "total" => 0
    ];
    file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT));
}

// ambil data
$data = json_decode(file_get_contents($file), true);

// waktu sekarang
$now = time();

// reset **today** kalau sudah lewat batas
if ($now >= strtotime($data["today_willreset"])) {
    $data["today"] = 0;
    $data["today_willreset"] = date("Y-m-d 00:00:00", strtotime("+1 day"));
}

// reset **week** kalau sudah lewat batas
if ($now >= strtotime($data["week_willreset"])) {
    $data["week"] = 0;
    $data["week_willreset"] = date("Y-m-d 00:00:00", strtotime("next monday"));
}

// tambah counter
$data["today"]++;
$data["week"]++;
$data["total"]++;

// simpan kembali
file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT));

// tampilkan (opsional)
echo "OK";
?>