<?php
$url = $_GET['url'] ?? '';
if (!$url) {
    header("Content-Type: text/plain");
    echo "Missing ?url parameter";
    exit;
}

$ch = curl_init($url);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HEADER => true,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 15,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_SSL_VERIFYHOST => false,
    CURLOPT_USERAGENT => "curl/8.0",
]);

$result = curl_exec($ch);
$error = curl_error($ch);
$info = curl_getinfo($ch);

curl_close($ch);

if ($error) {
    header("Content-Type: text/plain");
    echo "cURL ERROR: $error";
    exit;
}

$host = parse_url($url, PHP_URL_HOST) ?: "output";
$filename = $host . "--curli.txt";

header("Content-Type: text/plain");
header("Content-Disposition: attachment; filename=\"$filename\"");

echo $result;