<?php
header('Content-Type: application/json');

if (!isset($_GET['text']) || $_GET['text'] === '') {
    echo json_encode([
        "output" => "fail",
        "content" => [
            "reason" => "text parameter is missing"
        ]
    ], JSON_PRETTY_PRINT);
    exit;
}

$text = $_GET['text'];
$encoded = base64_encode($text);
$url = "https://tripweb.page.gd/userfile/bratimg/" . $encoded;

echo json_encode([
    "output" => "work",
    "content" => [
        "text" => $text,
        "url"  => $url
    ]
], JSON_PRETTY_PRINT);