<?php
if (!isset($_GET['text']) || $_GET['text'] === '') {
    http_response_code(400);
    exit('text parameter is missing');
}

/* decode base64 */
$decodedText = base64_decode($_GET['text'], true);

if ($decodedText === false) {
    http_response_code(400);
    exit('invalid base64 text');
}

/* build target url */
$targetUrl = 'https://api.yupra.my.id/api/video/bratv?text=' . urlencode($decodedText);

/* fetch image */
$ch = curl_init($targetUrl);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HEADER => true
]);

$response = curl_exec($ch);
$headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
$contentType = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($httpCode !== 200 || !$response) {
    http_response_code(502);
    exit('failed to load video');
}

/* output image */
$body = substr($response, $headerSize);
header("Content-Type: {$contentType}");
echo $body;