<?php
header('Content-Type: application/json');

if (!isset($_GET['gurl']) || empty($_GET['gurl'])) {
    echo json_encode([
        "output" => "fail",
        "content" => [
            "reason" => "github url is missing"
        ]
    ], JSON_PRETTY_PRINT);
    exit;
}

$gurl = trim($_GET['gurl']);

/* extract username */
if (!preg_match('#github\.com/([A-Za-z0-9_-]+)#', $gurl, $match)) {
    echo json_encode([
        "output" => "fail",
        "content" => [
            "reason" => "invalid github url"
        ]
    ], JSON_PRETTY_PRINT);
    exit;
}

$username = $match[1];
$apiUrl = "https://api.github.com/users/{$username}";

/* request to GitHub API */
$ch = curl_init($apiUrl);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_USERAGENT => 'PHP-GitHub-Client',
    CURLOPT_FOLLOWLOCATION => true
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($httpCode !== 200 || !$response) {
    echo json_encode([
        "output" => "fail",
        "content" => [
            "reason" => "not found"
        ]
    ], JSON_PRETTY_PRINT);
    exit;
}

$data = json_decode($response, true);

echo json_encode([
    "output" => "work",
    "content" => [
        "username"        => $data['login'],
        "bio"             => $data['bio'],
        "follower"        => $data['followers'],
        "following"       => $data['following'],
        "public repost"   => $data['public_repos'],
        "photo profile"   => $data['avatar_url']
    ]
], JSON_PRETTY_PRINT);