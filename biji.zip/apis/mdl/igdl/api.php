<?php
if (!isset($_GET['url'])) {
    http_response_code(400);
    exit('URL required');
}

$igUrl = base64_decode($_GET['url']);
if (!filter_var($igUrl, FILTER_VALIDATE_URL)) {
    http_response_code(400);
    exit('Invalid URL');
}

/*
 | Daftar API IGDL (tanpa key)
 | Jika satu gagal, lanjut ke berikutnya
 */
$apiList = [
    "https://saveig.app/api/ajaxSearch?url=",
    "https://snapinsta.app/api/ajaxSearch?url=",
    "https://igram.world/api/igdl?url=",
    "https://ssinstagram.com/api/convert?url=",
    "https://indown.io/api/ig?url=",
    "https://fastdl.app/api/search?url=",
    "https://igramer.app/api/search?url=",
    "https://instasupersave.com/api/convert?url=",
    "https://savefrom.net/api/convert?url=",
    "https://instaoffline.net/api/download?url="
];

$downloadUrl = null;

foreach ($apiList as $api) {
    $resp = @file_get_contents($api . urlencode($igUrl));
    if (!$resp) continue;

    $json = json_decode($resp, true);
    if (!$json) continue;

    /*
     | Normalisasi hasil (beda API beda struktur)
     */
    if (isset($json['data'][0]['url'])) {
        $downloadUrl = $json['data'][0]['url'];
        break;
    }
    if (isset($json['url'])) {
        $downloadUrl = $json['url'];
        break;
    }
    if (isset($json['links'][0]['url'])) {
        $downloadUrl = $json['links'][0]['url'];
        break;
    }
}

if (!$downloadUrl) {
    http_response_code(500);
    exit('Failed to fetch media');
}

/*
 | Force download
 */
header('Content-Description: File Transfer');
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="instagram_media.mp4"');
header('Content-Length: ' . filesize($downloadUrl));
readfile($downloadUrl);
exit;