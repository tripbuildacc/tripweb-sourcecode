<?php
header('Content-Type: application/json');

if (!isset($_GET['url']) || $_GET['url'] === '') {
    echo json_encode([
        "output" => "fail",
        "content" => [
            "reason" => "url parameter is missing"
        ]
    ], JSON_PRETTY_PRINT);
    exit;
}

$text = $_GET['url'];
$encoded = base64_encode($text);
$url = "https://tripweb.page.gd/userfile/igdl/" . $encoded;

echo json_encode([
    "output" => "work",
    "content" => [
        "text" => $text,
        "url"  => $url
    ]
], JSON_PRETTY_PRINT);