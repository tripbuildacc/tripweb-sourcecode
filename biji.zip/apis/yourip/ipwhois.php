<?php
header('Content-Type: application/json');

/* get IP */
if (isset($_GET['ip']) && !empty($_GET['ip'])) {
    $ip = trim($_GET['ip']);
} else {
    $ipify = @file_get_contents('https://api.ipify.org/?format=json');
    $ipifyData = json_decode($ipify, true);

    if (!isset($ipifyData['ip'])) {
        echo json_encode([
            "output" => "fail",
            "content" => [
                "reason" => "unable to get ip"
            ]
        ], JSON_PRETTY_PRINT);
        exit;
    }

    $ip = $ipifyData['ip'];
}

/* request ipwho.is */
$whois = @file_get_contents("https://ipwho.is/{$ip}");
$whoisData = json_decode($whois, true);

if (!$whoisData || !isset($whoisData['success']) || $whoisData['success'] !== true) {
    echo json_encode([
        "output" => "fail",
        "content" => [
            "reason" => "ipwhois lookup failed"
        ]
    ], JSON_PRETTY_PRINT);
    exit;
}

/* success */
echo json_encode([
    "output" => "work",
    "content" => $whoisData
], JSON_PRETTY_PRINT);