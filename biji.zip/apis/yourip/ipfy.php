<?php
header('Content-Type: application/json');

/* get public IP */
$ip = @file_get_contents('https://api.ipify.org/?format=json');
$data = json_decode($ip, true);

if (!isset($data['ip'])) {
    echo json_encode([
        "output" => "fail",
        "content" => [
            "reason" => "unable to fetch ip"
        ]
    ], JSON_PRETTY_PRINT);
    exit;
}

echo json_encode([
    "output" => "work",
    "content" => [
        "IP" => $data['ip']
    ]
], JSON_PRETTY_PRINT);