<?php
header('Content-Type: application/json');

if (!isset($_GET['text']) || empty($_GET['text'])) {
    echo json_encode([
        "output" => "fail",
        "content" => [
            "reason" => "empty or non-existent text"
        ]
    ], JSON_PRETTY_PRINT);
    exit;
}

$input = strtoupper(trim($_GET['text']));

if (!preg_match('/^[A-Z2-7=]+$/', $input)) {
    echo json_encode([
        "output" => "fail",
        "content" => [
            "reason" => "invalid base32"
        ]
    ], JSON_PRETTY_PRINT);
    exit;
}

function base32_decode_custom($data) {
    $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $data = rtrim($data, '=');
    $binary = '';

    foreach (str_split($data) as $char) {
        $pos = strpos($alphabet, $char);
        if ($pos === false) return false;
        $binary .= str_pad(decbin($pos), 5, '0', STR_PAD_LEFT);
    }

    $decoded = '';
    foreach (str_split($binary, 8) as $byte) {
        if (strlen($byte) === 8) {
            $decoded .= chr(bindec($byte));
        }
    }

    return $decoded;
}

$decoded = base32_decode_custom($input);

if ($decoded === false) {
    echo json_encode([
        "output" => "fail",
        "content" => [
            "reason" => "failed to decode"
        ]
    ], JSON_PRETTY_PRINT);
    exit;
}

echo json_encode([
    "output" => "work",
    "content" => [
        "real text" => $input,
        "decode base32" => $decoded
    ]
], JSON_PRETTY_PRINT);