<?php
header('Content-Type: application/json');

if (!isset($_GET['text'])) {
    echo json_encode([
        "output" => "fail",
        "content" => [
            "issue" => "no text provided"
        ]
    ]);
    exit;
}

$input = $_GET['text'];

// Encode to Base32
$encoded = base32_encode($input);

if ($encoded === false) {
    echo json_encode([
        "output" => "fail",
        "content" => [
            "real text" => $input,
            "issue" => "encode error"
        ]
    ]);
    exit;
}

echo json_encode([
    "output" => "work",
    "content" => [
        "real text" => $input,
        "encode base32" => $encoded
    ]
]);
exit;

// Base32 encode function
function base32_encode($data) {
    $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $binary = '';
    $output = '';

    foreach (str_split($data) as $char) {
        $binary .= str_pad(decbin(ord($char)), 8, '0', STR_PAD_LEFT);
    }

    $bits = str_split($binary, 5);

    foreach ($bits as $chunk) {
        if (strlen($chunk) < 5) {
            $chunk = str_pad($chunk, 5, '0', STR_PAD_RIGHT);
        }
        $output .= $alphabet[bindec($chunk)];
    }

    return $output;
}
?>