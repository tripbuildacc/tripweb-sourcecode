<?php
header("Location: https://tripweb.page.gd/apis/dashboard");
exit;