<?php
header('Content-Type: application/json');

$text = isset($_GET['text']) ? $_GET['text'] : '';
$invert = (isset($_GET['invert']) && $_GET['invert'] === 'true') ? 'true' : 'false';

if ($text === '') {
    echo json_encode([
        'output' => 'error',
        'message' => 'text is required'
    ]);
    exit;
}

$base64Text = base64_encode($text);

$url = "https://tripweb.page.gd/userfile/t2bc/{$base64Text}/invert/{$invert}";

echo json_encode([
    'output' => 'work',
    'content' => [
        'url' => $url
    ]
]);