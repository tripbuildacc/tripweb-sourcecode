<?php
header('Content-Type: image/png');

$text = isset($_GET['text']) ? base64_decode($_GET['text']) : ' ';
$invert = isset($_GET['invert']) && $_GET['invert'] === 'true';

// ambil QR code dari QuickChart
$qrUrl = "https://quickchart.io/qr?text=" . urlencode($text) . "&size=300";
$imgData = @file_get_contents($qrUrl);

if ($imgData === false) {
    $img = imagecreatetruecolor(300, 300);
    $bg = imagecolorallocate($img, 255, 255, 255);
    $fg = imagecolorallocate($img, 0, 0, 0);
    imagefill($img, 0, 0, $bg);
    imagestring($img, 5, 10, 140, "ERROR", $fg);
    imagepng($img);
    imagedestroy($img);
    exit;
}

$img = imagecreatefromstring($imgData);

if ($invert) {
    imagefilter($img, IMG_FILTER_NEGATE);
}

imagepng($img);
imagedestroy($img);
?>