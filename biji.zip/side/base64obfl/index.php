<?php
// Ambil parameter
$raw = isset($_GET['b64u']) ? $_GET['b64u'] : null;

if (!$raw) {
    http_response_code(400);
    echo "Parameter 'b64u' does not exist.";
    exit;
}

// Decode base64
$url = base64_decode($raw, true);

// Validate
if ($url === false || empty($url)) {
    http_response_code(400);
    echo "Invalid Base64.";
    exit;
}

// Redirect ke URL hasil decode
header("Location: " . $url);
exit;
?>