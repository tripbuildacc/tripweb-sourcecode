<?php
header("Location: https://tripweb.page.gd/side/dashboard");
exit;