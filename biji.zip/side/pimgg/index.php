<?php
$textBase64 = $_GET['text'] ?? '';
if ($textBase64 === '') {
    http_response_code(400);
    exit('text kosong');
}

// decode base64
$textDecoded = base64_decode($textBase64, true);
if ($textDecoded === false || trim($textDecoded) === '') {
    http_response_code(400);
    exit('base64 tidak valid');
}

// pecah kata
$words = preg_split('/\s+/', trim($textDecoded));

// maksimal 10 kata per baris
$lines = array_chunk($words, 10);
$textLines = array_map(fn($line) => implode(' ', $line), $lines);

$width  = 1000;
$height = 1000;

// canvas
$img = imagecreatetruecolor($width, $height);
$white = imagecolorallocate($img, 255, 255, 255);
$black = imagecolorallocate($img, 0, 0, 0);
imagefill($img, 0, 0, $white);

// font
$font = __DIR__ . '/font.ttf';
if (!file_exists($font)) {
    http_response_code(500);
    exit('font.ttf tidak ditemukan');
}

// auto font size
$fontSize = 120;
$minFontSize = 10;

do {
    $totalHeight = 0;
    $maxWidth = 0;

    foreach ($textLines as $line) {
        $box = imagettfbbox($fontSize, 0, $font, $line);
        $lineWidth  = abs($box[4] - $box[0]);
        $lineHeight = abs($box[5] - $box[1]);

        $totalHeight += $lineHeight + 10;
        $maxWidth = max($maxWidth, $lineWidth);
    }

    $fontSize--;
} while (
    ($maxWidth > $width - 80 || $totalHeight > $height - 80)
    && $fontSize > $minFontSize
);

// posisi tengah vertikal
$y = ($height - $totalHeight) / 2;

foreach ($textLines as $line) {
    $box = imagettfbbox($fontSize, 0, $font, $line);
    $lineWidth  = abs($box[4] - $box[0]);
    $lineHeight = abs($box[5] - $box[1]);

    $x = ($width - $lineWidth) / 2;
    $y += $lineHeight;

    imagettftext($img, $fontSize, 0, $x, $y, $black, $font, $line);
    $y += 10;
}

// output
header('Content-Type: image/png');
imagepng($img);
imagedestroy($img);