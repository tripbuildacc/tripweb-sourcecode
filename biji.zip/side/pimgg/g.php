<?php
$code = $_GET['text'] ?? '';

$target = 'https://tripweb.page.gd/userfile/pimgg/' . $code;

header('Location: ' . $target, true, 302);
exit;