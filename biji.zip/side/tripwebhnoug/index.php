<?php
$text = '';

if (!isset($_GET['code']) || $_GET['code'] === '') {
    $text = 'enter ?code={code} stupid';
} else {
    $decoded = base64_decode($_GET['code'], true);

    if ($decoded === false) {
        $text = 'invalid code';
    } else {
        $text = htmlspecialchars($decoded, ENT_QUOTES, 'UTF-8');
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="0">
<title>Tripweb Side</title>
<link rel="icon" type="image/png" href="https://tripweb.page.gd/library/weblogo.png"/>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
<style>
body{
    margin: 0;
    height: 100vh;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    background: #1e1e1e;
    color: #fff;
    font-family: 'Inter', sans-serif;
    text-align: center;
}
h1{
    margin: 0;
    font-size: 3rem;
    color: #ffcc00;
}
p{
    margin: 8px 0 0;
    font-size: 1rem;
    color: #bbb;
}
</style>
</head>
<body>
    <h1></h1>
    <p><?= $text ?></p>
</body>
</html>