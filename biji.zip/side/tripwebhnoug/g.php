<?php
$code = $_GET['code'] ?? '';

$target = 'https://tripweb.page.gd/userfile/tripwebhnoug/' . $code;

header('Location: ' . $target, true, 302);
exit;