<?php
header("Location: https://tripweb.page.gd/dashboard");
exit;